import keyword
print(keyword.softkwlist)
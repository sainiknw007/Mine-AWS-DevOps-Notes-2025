import keyword
print(len(keyword.kwlist))
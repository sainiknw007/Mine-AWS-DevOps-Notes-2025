import platform
print(platform.python_version())